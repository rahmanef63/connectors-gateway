## What changed

## Which contract is affected?

- [ ] Connector manifest
- [ ] Gateway protocol
- [ ] Device protocol
- [ ] Policy/security
- [ ] Adapter only
- [ ] Documentation only

## Security check

- [ ] No new inbound local port
- [ ] No secret/token logged
- [ ] No caller-controlled identity added
- [ ] Action risk metadata reviewed
- [ ] Arbitrary code execution remains disabled by default
- [ ] Backward compatibility reviewed

## Test evidence
